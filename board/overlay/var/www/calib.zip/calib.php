<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Calibration</title>
</head>

<body>
<h1>Calibration </h1>

<form id="config_form" name="configForm" method="post">
<?php

   if ($_SERVER['REQUEST_METHOD'] === 'GET')
   {

     class MyDB extends SQLite3
     {
     	function __construct()
     	{
     		$this->open("/home/launchApps/Apps/ChargerApps/sqlite/charger.db");
     	}
     }
        $db = new MyDB();

        if(!$db){
           	echo "Could not open DB!!!";
     	echo $db->lastErrorMsg();
        } else {
           //echo "Opened database successfully<br/>";
           echo "<br>";
        }

      //echo "This is get request";
      //echo "<br>";
      //echo "<br>";

      $sql = "select * from keys";

      $ret = $db->query($sql);

      while($row = $ret->fetchArray(SQLITE3_ASSOC))
      {

   	   if
        (
         ($row['key'] === 'adc4offset') ||
         ($row['key'] === 'adc4gain')

   	   ){

   		   echo $row['key'];
   	     echo "<br>";
   		   echo "<input type=\"text\" name=\"".$row['key']."\" value=\"".$row['value']."\" placeholder=\"Enter Value\">";
   		   echo "<br>";
   	    }
      }

      $db->close();
      echo "<br>";
      echo "<input type=\"submit\">";


   }else if ($_SERVER['REQUEST_METHOD'] === 'POST'){

      //echo "This is post request";
      echo "<br>";
      echo "<br>";

      class MyDB extends SQLite3
      {
      	function __construct()
      	{
      		$this->open("/home/launchApps/Apps/ChargerApps/sqlite/charger.db");
      	}
      }
         $db = new MyDB();

         if(!$db){
            	echo "Could not open DB!!!";
      	echo $db->lastErrorMsg();
         } else {
            //echo "Opened database successfully<br/>";
            echo "<br>";
         }


      $n ="";
      $o ="";


      $sqlb ="replace into keys(key , value) VALUES (";
      $sqle =");";
      $pramCount = 0;


      if(isset($_POST["adc4offset"])){

        $n =  $_POST["adc4offset"];
        $pramCount++;
        echo $n;
      }

      if(isset($_POST["adc4gain"])){

        $o =  $_POST["adc4gain"];
        $pramCount++;
        echo $o;
      }

      //echo $pramCount;

    $sql14 =	  $sqlb."'adc4offset',"."'".$n."'".$sqle;
    $sql15 =	  $sqlb."'adc4gain',"."'".$o."'".$sqle;


    if($pramCount === 2){

      echo "Before execution <br>";
      //echo $sql8;

      $db->exec($sql14);
      $db->exec($sql15);

      $pramCount = 0;
      $db->close();

      echo "Done updating Database <br>";

    }else if($pramCount === 0){

      echo "You have not done anything<br>";
      $db->close();

    }


   }

 ?>

   </form>
 </body>
</html>
