#!/bin/sh

export LD_LIBRARY_PATH=/usr/local/lib

a=$(sqlite3 /home/launchApps/Apps/ChargerApps/cR1/sqlite/db "SELECT value FROM keys where key = 'fwdir';")
echo $a
/home/launchApps/Apps/ChargerApps/cR1/$a/./EvdcApp -platform xcb

while [ "<return value of TestMDI >" != "0"  ]
do
  	sleep 10s
	echo "Re-executing Application"
	b=$(sqlite3 /home/launchApps/Apps/ChargerApps/cR1/sqlite/db "SELECT value FROM keys where key = 'fwdir';")
	echo $b	
	/home/launchApps/Apps/ChargerApps/cR1/$b/./EvdcApp -platform xcb
done
echo "Closed"
